<!-- Footer
================================================== -->
<footer class="bs-docs-footer" role="contentinfo">
    <div class="divider"></div>

      <p>Anchor is made by <a href="http://twitter.com/idiot" target="_blank">@idiot</a> and <a href="http://twitter.com/kieronwilson" target="_blank">@kieronwilson</a>.</p>
    
    </div>
</footer>
<script type="text/javascript" src="//platform.twitter.com/widgets.js"></script>

  </body>
</html>