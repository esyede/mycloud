<?php theme_include('header'); ?>
<main class="bs-docs-masthead" id="content" role="main"><div style="padding: 30px 15px; "><div style="padding: 50px 0;">
  
  <div class="container">
    
    <h1>WTF? 404 ERROR HERE.</h1>
    
  </div>
  
</div></div>
</main>
<?php theme_include('footer'); ?>