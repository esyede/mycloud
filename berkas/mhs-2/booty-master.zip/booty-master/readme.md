# Booty 3

Anchor theme powered by Twitter Bootstrap 3.

**Now available with Bootstrap 3.**

![screenshot.](http://cl.ly/WuAm/booty3.png)

## Why you'll love Booty

* Nice fonts and typography.
* Work fine with latest Anchor version.
* Made in Q3 2014.
* Aweesome features (like cover image or links color).
* Royalty free.

## How to install Booty

Download Booty from this repo. Put it into `themes` folder on your Anchor blog and activate it from admin.

## Need support?

[Go to the Anchor CMS official Forums.](http://forums.anchorcms.com)
