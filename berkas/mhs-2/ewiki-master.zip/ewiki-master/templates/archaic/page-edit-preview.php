<div class="warning">
This is only a <em>preview</em> of the final page, your work has not yet been saved. To do so, click the “Save” button.
</div>
<?= $contents ?>
