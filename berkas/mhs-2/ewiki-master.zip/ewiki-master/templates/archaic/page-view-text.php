<?= $page->format() ?>
