<p>
    <a href="<?= $page->getURL() ?>?action=get&amp;commit=<?= $commit_id ?>">
        Download “<?= Markup::escape($page->getName()) ?>”
    </a>
</p>
